[**@ensdomains/ensjs**](../README.md)

---

> wallet

# Module: wallet

## Index

- [clearRecords](function.clearRecords.md)
- [commitName](function.commitName.md)
- [createSubname](function.createSubname.md)
- [deleteSubname](function.deleteSubname.md)
- [registerName](function.registerName.md)
- [renewNames](function.renewNames.md)
- [setAbiRecord](function.setAbiRecord.md)
- [setAddressRecord](function.setAddressRecord.md)
- [setChildFuses](function.setChildFuses.md)
- [setContentHashRecord](function.setContentHashRecord.md)
- [setFuses](function.setFuses.md)
- [setPrimaryName](function.setPrimaryName.md)
- [setRecords](function.setRecords.md)
- [setResolver](function.setResolver.md)
- [setTextRecord](function.setTextRecord.md)
- [transferName](function.transferName.md)
- [unwrapName](function.unwrapName.md)
- [wrapName](function.wrapName.md)

---

Generated using [TypeDoc](https://typedoc.org/) and [typedoc-plugin-markdown](https://www.npmjs.com/package/typedoc-plugin-markdown)
