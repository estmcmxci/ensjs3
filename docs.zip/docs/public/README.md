[**@ensdomains/ensjs**](../README.md)

---

> public

# Module: public

## Index

- [batch](function.batch.md)
- [getAbiRecord](function.getAbiRecord.md)
- [getAddressRecord](function.getAddressRecord.md)
- [getAvailable](function.getAvailable.md)
- [getContentHashRecord](function.getContentHashRecord.md)
- [getExpiry](function.getExpiry.md)
- [getName](function.getName.md)
- [getOwner](function.getOwner.md)
- [getPrice](function.getPrice.md)
- [getRecords](function.getRecords.md)
- [getResolver](function.getResolver.md)
- [getSupportedInterfaces](function.getSupportedInterfaces.md)
- [getTextRecord](function.getTextRecord.md)
- [getWrapperData](function.getWrapperData.md)

---

Generated using [TypeDoc](https://typedoc.org/) and [typedoc-plugin-markdown](https://www.npmjs.com/package/typedoc-plugin-markdown)
