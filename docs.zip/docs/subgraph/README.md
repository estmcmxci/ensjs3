[**@ensdomains/ensjs**](../README.md)

---

> subgraph

# Module: subgraph

## Index

- [getDecodedName](function.getDecodedName.md)
- [getNameHistory](function.getNameHistory.md)
- [getNamesForAddress](function.getNamesForAddress.md)
- [getSubgraphRecords](function.getSubgraphRecords.md)
- [getSubgraphRegistrant](function.getSubgraphRegistrant.md)
- [getSubnames](function.getSubnames.md)

---

Generated using [TypeDoc](https://typedoc.org/) and [typedoc-plugin-markdown](https://www.npmjs.com/package/typedoc-plugin-markdown)
