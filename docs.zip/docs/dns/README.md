[**@ensdomains/ensjs**](../README.md)

---

> dns

# Module: dns

## Index

- [getDnsImportData](function.getDnsImportData.md)
- [getDnsOwner](function.getDnsOwner.md)
- [importDnsName](function.importDnsName.md)

---

Generated using [TypeDoc](https://typedoc.org/) and [typedoc-plugin-markdown](https://www.npmjs.com/package/typedoc-plugin-markdown)
